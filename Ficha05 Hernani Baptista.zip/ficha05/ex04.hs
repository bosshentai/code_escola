--ordem superior
-- recebe lista
-- retorna lista invertida

teste = ["maria","luis"]
teste2 = ["1","3","4"]
teste3 = [1,2,3,4]

reverter_lista x = reverse x