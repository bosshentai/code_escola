identicos:: Int -> a -> [a]
identicos num b = [b]