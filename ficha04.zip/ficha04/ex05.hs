selectElement:: [a] -> Int -> a
selectElement xs location = xs!!location