-- verificar todos os elementos da lista sao True
--isTrue:: [Bool] -> Bool
--isTrue [] = False
--isTrue (xs) =  isTrue teste
--             where
--                teste = [ a | a <- xs , a == True]

